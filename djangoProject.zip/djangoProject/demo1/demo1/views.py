from django.http import HttpResponse


def home(request):
    return HttpResponse('<h1>Hello from Django</h1>')

def about(request):
    return HttpResponse('<h1>This is about Page</h1>')

def contact(request):
    return HttpResponse('<h1>This is Contact Page!!</h1>')
def Address(request):
    return HttpResponse('<h1>This is Address Page!!</h1>')

def Technology(request):
    return HttpResponse('<h1>Welcome to the Technology World!!AI Innovations!!</h1>')

def web(request):
    return HttpResponse('<h1>Welcome to Web Page!!</h1>')

def mobile(request):
    return HttpResponse('<h1>This is mobile Page!!</h1>')

def desktop(request):
    return HttpResponse('<h1>Welcome to Desktop Page!!</h1>')

